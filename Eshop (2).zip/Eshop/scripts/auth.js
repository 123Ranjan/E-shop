// scripts/auth.js

// Check if user is logged in
function checkAuth() {
    return localStorage.getItem('isLoggedIn') === 'true';
}

// Get user data
function getUserData() {
    return {
        email: localStorage.getItem('userEmail'),
        name: localStorage.getItem('userName')
    };
}

// Set login status
function setLoginStatus(status, email = '', name = '') {
    localStorage.setItem('isLoggedIn', status);
    if (email) localStorage.setItem('userEmail', email);
    if (name) localStorage.setItem('userName', name);
}

// Redirect to login if not authenticated
function requireAuth() {
    if (!checkAuth()) {
        window.location.href = 'login.html';
    }
}

// Redirect to home if already authenticated
function redirectIfAuthenticated() {
    if (checkAuth()) {
        window.location.href = 'index.html';
    }
}

// Logout function
function logout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userName');
    window.location.href = 'login.html';
}