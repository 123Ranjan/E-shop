let bagItemObjects;
let isLoggedIn = false;

onLoad();

function onLoad(){
  checkLoginStatus();
  loadBagItemObjects();
  displayBagItems();
  displayBagSummary();
}

function checkLoginStatus() {
  isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  if (!isLoggedIn) {
    window.location.href = 'login.html';
  }
}

function displayBagSummary(){
  let bagSummaryElement = document.querySelector('.bag-summary');
  let total_items = bagItemObjects.length;
  let total_price = 0;
  let total_discount = 0;
  
  bagItemObjects.forEach(bagItem => {
    total_price += bagItem.original_price;
    total_discount += bagItem.original_price - bagItem.current_price;
  });
  
  let final_payment = total_price - total_discount + 99;

  bagSummaryElement.innerHTML = `  
    <div class="bag-details-container">
      <div class="price-header">PRICE DETAILS (${total_items} Items) </div>
      <div class="price-item">
        <span class="price-item-tag">Total MRP</span>
        <span class="price-item-value">₹${total_price}</span>
      </div>
      <div class="price-item">
        <span class="price-item-tag">Discount on MRP</span>
        <span class="price-item-value priceDetail-base-discount">-₹${total_discount}</span>
      </div>
      <div class="price-item">
        <span class="price-item-tag">Convenience Fee</span>
        <span class="price-item-value">₹99</span>
      </div>
      <hr>
      <div class="price-footer">
        <span class="price-item-tag">Total Amount</span>
        <span class="price-item-value">₹${final_payment}</span>
      </div>
    </div>
    <button class="btn-place-order" onclick="redirectToPayment()">
      <div class="css-xjhrni">PLACE ORDER</div>
    </button>`;
}

function redirectToPayment() {
  // Save order details to localStorage
  const orderDetails = {
    items: bagItemObjects,
    total: calculateOrderTotal()
  };
  localStorage.setItem('orderDetails', JSON.stringify(orderDetails));
  
  // Redirect to payment page
  window.location.href = 'payment.html';
}

function calculateOrderTotal() {
  let total_price = 0;
  let total_discount = 0;
  
  bagItemObjects.forEach(bagItem => {
    total_price += bagItem.original_price;
    total_discount += bagItem.original_price - bagItem.current_price;
  });
  
  return total_price - total_discount + 99;
}

function loadBagItemObjects() {
  // Get bagItems from localStorage
  let bagItemsStr = localStorage.getItem('bagItems');
  let bagItems = bagItemsStr ? JSON.parse(bagItemsStr) : [];
  
  console.log(bagItems);
  bagItemObjects = bagItems.map(itemId => {
    for (let i = 0; i < items.length; i++) {
      if (itemId == items[i].id) {
        return items[i];
      }
    }
  }).filter(item => item !== undefined);
  console.log(bagItemObjects);
}

function displayBagItems(){
  let containerElement = document.querySelector('.bag-items-container');
  let innerHTML = '';
  bagItemObjects.forEach(bagitem => {
    innerHTML += generateItemHTML(bagitem);
  });
  containerElement.innerHTML = innerHTML;
}

function removeFromBag(itemId){
  // Get current bag items
  let bagItemsStr = localStorage.getItem('bagItems');
  let bagItems = bagItemsStr ? JSON.parse(bagItemsStr) : [];
  
  // Remove the item
  bagItems = bagItems.filter(bagItemId => bagItemId != itemId);
  localStorage.setItem('bagItems', JSON.stringify(bagItems));
  
  // Reload and redisplay
  loadBagItemObjects();
  displayBagItems();
  
  // Update bag icon count (you'll need to implement this function)
  updateBagIconCount();
  
  displayBagSummary();
}

function generateItemHTML(item){
  return `  
    <div class="bag-item-container">
      <div class="item-left-part">
        <img class="bag-item-img" src="${item.image}">
      </div>
      <div class="item-right-part">
        <div class="company">${item.company}</div>
        <div class="item-name">${item.item_name}</div>
        <div class="price-container">
          <span class="current-price">Rs ${item.current_price}</span>
          <span class="original-price">Rs ${item.original_price}</span>
          <span class="discount-percentage">(${item.discount_percentage}% OFF)</span>
        </div>
        <div class="return-period">
          <span class="return-period-days">${item.return_period} days</span> return available
        </div>
        <div class="delivery-details">
          Delivery by
          <span class="delivery-details-days">${item.delivery_date}</span>
        </div>
      </div>
      <div class="remove-from-cart" onclick="removeFromBag(${item.id})">X</div>
    </div>`;
}

// Function to update bag icon count (you need to implement this)
function updateBagIconCount() {
  let bagItemsStr = localStorage.getItem('bagItems');
  let bagItems = bagItemsStr ? JSON.parse(bagItemsStr) : [];
  let bagItemCountElement = document.querySelector('.bag-item-count');
  
  if (bagItems.length > 0) {
    bagItemCountElement.style.visibility = 'visible';
    bagItemCountElement.innerText = bagItems.length;
  } else {
    bagItemCountElement.style.visibility = 'hidden';
  }
}

// Make sure items array is available (from items.js)
if (typeof items === 'undefined') {
  // If items is not defined, try to load it
  console.error('Items array not found. Make sure items.js is loaded before bag.js');
}