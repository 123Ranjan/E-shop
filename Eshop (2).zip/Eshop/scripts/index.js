// scripts/index.js
let bagItems;

// Load function
function onLoad(){
    // Check authentication
    if (typeof requireAuth === 'function') {
        requireAuth();
    }
    
    let bagItemsStr = localStorage.getItem('bagItems');
    bagItems = bagItemsStr ? JSON.parse(bagItemsStr) : [];
    displayItems();
    dispalyBagIcon();
    
    // Update user info if available
    updateUserInfo();
}

// Update user information in the UI
function updateUserInfo() {
    if (typeof getUserData === 'function') {
        const userData = getUserData();
        const userInfoElement = document.getElementById('user-info');
        
        if (userInfoElement && userData.email) {
            userInfoElement.innerHTML = `
                <div>${userData.name || 'User'}</div>
                <div class="user-email">${userData.email}</div>
            `;
        }
    }
}

// Add to bag function
function addToBag(itemId){
    if (typeof checkAuth === 'function' && !checkAuth()) {
        window.location.href = 'login.html';
        return;
    }
    
    bagItems.push(itemId);
    localStorage.setItem('bagItems', JSON.stringify(bagItems));
    dispalyBagIcon();
}

// Display bag icon
function dispalyBagIcon(){
    let bagItemCountElement = document.querySelector('.bag-item-count');
    if (bagItemCountElement) {
        if (bagItems.length > 0) {
            bagItemCountElement.style.visibility = 'visible';
            bagItemCountElement.innerText = bagItems.length; 
        } else {
            bagItemCountElement.style.visibility = 'hidden';
        }
    }
}

// Display items
function displayItems(){
    let itemsContainerElement = document.querySelector('.items-container');
    if (!itemsContainerElement) {
        return;
    }
    
    let innerHTML = '';
    items.forEach(item => {
        innerHTML += `
            <div class="item-container">
                <img class="item-image" src="${item.image}" alt="item image">
                <div class="rating">
                    ${item.rating.stars}⭐|${item.rating.count}k
                </div>
                <div class="company-name">${item.company}</div>
                <div class="item-name">${item.item_name}</div>
                <div class="price">
                    <span class="current-price">Rs ${item.current_price}</span>
                    <span class="original-price">Rs ${item.original_price}</span>
                    <span class="discount">(${item.discount_percentage}% OFF)</span>
                </div>
                <button class="btn-add-bag" onclick="addToBag(${item.id})">Add to Bag</button>
            </div>
        `;
    });

    itemsContainerElement.innerHTML = innerHTML;
}

// Initialize when page loads
onLoad();